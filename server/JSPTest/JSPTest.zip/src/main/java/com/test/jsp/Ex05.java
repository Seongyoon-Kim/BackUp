package com.test.jsp;

public class Ex05 {
	
	public int sum(int a, int b) {
		
		return a + b;
		
	}

}
