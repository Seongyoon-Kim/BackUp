package com.test.jsp.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Ex04_select {
   
   public static void main(String[] args) {
      
      //Ex04_select.java
      
      //반환값이 있는 쿼리 -> select문
      
      template();
      m1();
      
   }//main

   private static void template() {
      
      Connection conn = null;
      Statement stat = null;
      ResultSet rs = null;
      
      try {
         
         conn = DBUtil.open();
         stat = conn.createStatement();
         
         String sql = "";
         
         stat.close();
         conn.close();
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      
      
   }//template

   private static void m1() {
      
      //단일값 변환 select
      // -> select -> 1행 1열
      // -> select -> N행 N열
      
      Connection conn = null;
      Statement stat = null;
      ResultSet rs = null;
      
      try {
         
         conn = DBUtil.open();
         stat = conn.createStatement();
         
         String sql = "select count(*) from tblAddress";
         
         rs = stat.executeQuery(sql);
         
         // rs??? -> 결과 테이블
         
         // 커서를 다음 레코드를 전진시킨다.
         rs.next();
         
         // 커서가 가리키고 있는 레코드의 특정 컬럼값을 가져온다.
         // rs.getXXX();
         int count = rs.getInt(1);
         System.out.println("인원수: " + count);
         
         String strCount = rs.getString(1);
         System.out.println("인원수: " + strCount);
         
         rs.close();
         stat.close();
         conn.close();
         
      } catch (Exception e) {
         e.printStackTrace();
      }

   }//m1
   
}//Ex04_select
















