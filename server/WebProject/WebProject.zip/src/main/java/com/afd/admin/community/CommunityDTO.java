package com.afd.admin.community;

public class CommunityDTO {

}
