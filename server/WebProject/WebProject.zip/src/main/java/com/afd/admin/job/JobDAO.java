package com.afd.admin.job;

public class JobDAO {

}
