package com.afd.admin.job;

public class JobList {

}
