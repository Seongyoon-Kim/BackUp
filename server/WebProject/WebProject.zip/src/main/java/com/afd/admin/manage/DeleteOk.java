package com.afd.admin.manage;

public class DeleteOk {

}
