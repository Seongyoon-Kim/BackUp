package com.afd.admin.space;

public class Delete {

}
