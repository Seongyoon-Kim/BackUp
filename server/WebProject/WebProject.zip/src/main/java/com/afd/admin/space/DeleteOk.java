package com.afd.admin.space;

public class DeleteOk {

}
