package com.afd.admin.study;

public class CommentDTO {

}
