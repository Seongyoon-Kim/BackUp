package com.afd.company.job;

public class JobList {

}
