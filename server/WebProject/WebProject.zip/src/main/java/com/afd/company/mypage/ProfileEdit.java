package com.afd.company.mypage;

public class ProfileEdit {

}
