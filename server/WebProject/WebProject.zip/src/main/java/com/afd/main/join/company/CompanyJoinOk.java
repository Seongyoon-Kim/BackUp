package com.afd.main.join.company;

public class CompanyJoinOk {

}
