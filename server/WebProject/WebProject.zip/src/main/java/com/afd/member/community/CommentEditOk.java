package com.afd.member.community;

public class CommentEditOk {

}
