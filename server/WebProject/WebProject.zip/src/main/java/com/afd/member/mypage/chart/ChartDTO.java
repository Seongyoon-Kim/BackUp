package com.afd.member.mypage.chart;

public class ChartDTO {
	
	private String name;
	private String qnaCount;
	private String communityCount;
	private String studyCount;
	private String qnaCommentCount;
	private String communityCommentCount;
	private String studyCommentCount;
	private String memberSeq;
	
	public String getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(String memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQnaCount() {
		return qnaCount;
	}
	public void setQnaCount(String qnaCount) {
		this.qnaCount = qnaCount;
	}
	public String getCommunityCount() {
		return communityCount;
	}
	public void setCommunityCount(String communityCount) {
		this.communityCount = communityCount;
	}
	public String getStudyCount() {
		return studyCount;
	}
	public void setStudyCount(String studyCount) {
		this.studyCount = studyCount;
	}
	public String getQnaCommentCount() {
		return qnaCommentCount;
	}
	public void setQnaCommentCount(String qnaCommentCount) {
		this.qnaCommentCount = qnaCommentCount;
	}
	public String getCommunityCommentCount() {
		return communityCommentCount;
	}
	public void setCommunityCommentCount(String communityCommentCount) {
		this.communityCommentCount = communityCommentCount;
	}
	public String getStudyCommentCount() {
		return studyCommentCount;
	}
	public void setStudyCommentCount(String studyCommentCount) {
		this.studyCommentCount = studyCommentCount;
	}

}
