package com.afd.member.mypage.myjob;

public class JobList {

}
