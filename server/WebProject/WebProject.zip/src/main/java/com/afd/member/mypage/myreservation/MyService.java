package com.afd.member.mypage.myreservation;

public class MyService {

}
