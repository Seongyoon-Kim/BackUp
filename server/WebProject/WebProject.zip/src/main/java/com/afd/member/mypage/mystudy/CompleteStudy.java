package com.afd.member.mypage.mystudy;

public class CompleteStudy {

}
