package com.afd.member.space;

public class SpaceImageDTO {
	private String imageName;

	public SpaceImageDTO() {
		super();
	}
	
	public SpaceImageDTO(String imageName) {
		super();
		this.imageName = imageName;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	
	
	
}
