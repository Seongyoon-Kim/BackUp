package com.afd.member.study;

public class EditOk {

}
