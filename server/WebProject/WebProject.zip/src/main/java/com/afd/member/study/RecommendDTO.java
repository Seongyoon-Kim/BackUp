package com.afd.member.study;

public class RecommendDTO {
	
	private String studyRecommendSeq; 
	private String recommend; 
	private String recommendMemberSeq; 
	private String recommendPostSeq;
	
	public String getStudyRecommendSeq() {
		return studyRecommendSeq;
	}
	public void setStudyRecommendSeq(String studyRecommendSeq) {
		this.studyRecommendSeq = studyRecommendSeq;
	}
	public String getRecommend() {
		return recommend;
	}
	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}
	public String getRecommendMemberSeq() {
		return recommendMemberSeq;
	}
	public void setRecommendMemberSeq(String recommendMemberSeq) {
		this.recommendMemberSeq = recommendMemberSeq;
	}
	public String getRecommendPostSeq() {
		return recommendPostSeq;
	}
	public void setRecommendPostSeq(String recommendPostSeq) {
		this.recommendPostSeq = recommendPostSeq;
	} 
	
	 

}
