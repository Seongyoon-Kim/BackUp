package com.afd.member.study;

public class ScrapDTO {
	
	private String scrapSeq; 
	private String scrapMemberSeq; 
	private String scrapStudyPost;
	
	
	public String getScrapSeq() {
		return scrapSeq;
	}
	public void setScrapSeq(String scrapSeq) {
		this.scrapSeq = scrapSeq;
	}
	public String getScrapMemberSeq() {
		return scrapMemberSeq;
	}
	public void setScrapMemberSeq(String scrapMemberSeq) {
		this.scrapMemberSeq = scrapMemberSeq;
	}
	public String getScrapStudyPost() {
		return scrapStudyPost;
	}
	public void setScrapStudyPost(String scrapStudyPost) {
		this.scrapStudyPost = scrapStudyPost;
	}
	
	

}
