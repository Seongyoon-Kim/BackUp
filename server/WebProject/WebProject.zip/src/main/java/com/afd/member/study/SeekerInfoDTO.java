package com.afd.member.study;

public class SeekerInfoDTO {
	
	 
	 private String seekerInfoSeq;
	 private String studyPostSeq;
	 private String memberSeq;
	 private String seekerCheck;
	 private String evalComplete;
	 
	 
	 
	 
	public String getEvalComplete() {
		return evalComplete;
	}
	public void setEvalComplete(String evalComplete) {
		this.evalComplete = evalComplete;
	}
	public String getSeekerInfoSeq() {
		return seekerInfoSeq;
	}
	public void setSeekerInfoSeq(String seekerInfoSeq) {
		this.seekerInfoSeq = seekerInfoSeq;
	}
	public String getStudyPostSeq() {
		return studyPostSeq;
	}
	public void setStudyPostSeq(String studyPostSeq) {
		this.studyPostSeq = studyPostSeq;
	}
	public String getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(String memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getSeekerCheck() {
		return seekerCheck;
	}
	public void setSeekerCheck(String seekerCheck) {
		this.seekerCheck = seekerCheck;
	}
	 
	 

}
