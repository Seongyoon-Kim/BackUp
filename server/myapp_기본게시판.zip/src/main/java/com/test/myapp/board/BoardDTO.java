package com.test.myapp.board;

// 보통 오라클 테이블 1개당 DTO 1개(이상)를 만든다.
public class BoardDTO {
	
	private String seq;
	private String id;
	private String subject;
	private String content;
	private String tag;
	private String regdate;
	private String readcount;
	private String name;
	private String isnew;
	
	public String getIsnew() {
		return isnew;
	}
	public void setIsnew(String isnew) {
		this.isnew = isnew;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getReadcount() {
		return readcount;
	}
	public void setReadcount(String readcount) {
		this.readcount = readcount;
	}
	
	@Override
	public String toString() {
		return "BoardDTO [seq=" + seq + ", id=" + id + ", subject=" + subject + ", content=" + content + ", tag=" + tag
				+ ", regdate=" + regdate + ", readcount=" + readcount + ", name=" + name + ", isnew=" + isnew + "]";
	}
	
}
