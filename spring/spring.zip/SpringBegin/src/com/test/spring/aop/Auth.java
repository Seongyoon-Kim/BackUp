package com.test.spring.aop;

public class Auth {

	public void check() {
		//세션 -> 로그인 유무
		System.out.println("[auth] 로그인한 회원인지 확인합니다.");
	}

}
