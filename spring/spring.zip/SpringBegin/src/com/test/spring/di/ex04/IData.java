package com.test.spring.di.ex04;

import java.util.ArrayList;

public interface IData {
	
	ArrayList<String> get();

}
