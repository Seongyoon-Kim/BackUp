package com.test.spring.di.ex05;

import java.util.ArrayList;

public interface IData {
	
	ArrayList<String> get();

}
