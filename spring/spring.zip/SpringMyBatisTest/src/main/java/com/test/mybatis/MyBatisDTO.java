package com.test.mybatis;

import lombok.Data;

@Data
public class MyBatisDTO {
	
	private String seq;
	private String name;
	private String memo;
	private String regdate;
	private String category;

}
