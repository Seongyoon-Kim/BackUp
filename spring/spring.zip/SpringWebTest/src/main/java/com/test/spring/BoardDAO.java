package com.test.spring;

public class BoardDAO {

}
