package com.test.spring;

public class DataDAO {

	public void add(DataDTO dto) {
		
		System.out.println(dto);
		
	}

}
