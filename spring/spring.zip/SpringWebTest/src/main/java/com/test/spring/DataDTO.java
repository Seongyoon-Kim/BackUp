package com.test.spring;

import lombok.Data;

@Data
public class DataDTO {
	
	private String name;
	private String age;
	private String address;
	private String tel;
	private String email;

}
